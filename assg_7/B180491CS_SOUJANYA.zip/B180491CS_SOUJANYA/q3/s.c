#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 
#define BUFFER_SIZE 1024
#define MAX_REQUEST_SIZE 200
#define PORT_NUMBER	 8080
#define SA struct sockaddr
#define MAXLINE 1024 
char *hello = "HTTP/1.1 200 OK\nContent-Type: text/plain\nContent-Length: 30\n\nWelcome to Networks Lab!\n";

int get_reqest_page(char *request, char *page)
{
    char *start = "GET /";
    int i = 0;
    for (i = 0; i < strlen(start); i++)
    {
        if (start[i] != request[i])
            return 0;
    }
    int j = 0;
    for (; i < strlen(request); i++)
    {
        if (request[i] == ' ')
            break;
        page[j] = request[i];
        j++;
    }

    if (i == strlen(request))
        return 0;
    return 1;
}
// Driver code 
int main() { 
	int sockfd, connfd, len; 
	struct sockaddr_in servaddr, cli; 
	int n; 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) { 
		printf("socket creation failed...\n"); 
		exit(0); 
	} 
	else
		printf("Socket successfully created..\n"); 

	memset(&servaddr,0, sizeof(servaddr));
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT_NUMBER);

	// Binding newly created socket to given IP and verification 
	if ((bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr))) != 0) { 
		printf("Socket bind failed\n"); 
		exit(0); 
	} 
	else
		printf("Socket successfully binded\n"); 

	// Now server is ready to listen and verification 
	if ((listen(sockfd, 5)) != 0) { 
		printf("Listen failed\n"); 
		exit(0); 
	} 
	else
		printf("Server listening\n"); 
	len = sizeof(cli); 

	// Accept the data packet from client and verification 
	
    while(1)
    {
        connfd = accept(sockfd, (SA*)&cli, &len); 
        if (connfd < 0) { 
            printf("Server acccept failed\n"); 
            exit(0); 
        } 
        else
            printf("Server acccept the client\n"); 
        printf("\n[+] New Client Request has been received.\n");
        
        
        char buffer[BUFFER_SIZE] = {0};
        char page_buffer[BUFFER_SIZE];

        int recv_len = recv(connfd, buffer, BUFFER_SIZE, 0);
        int count =0 ; 
        int x = 0;
        char request[MAX_REQUEST_SIZE] = {0};
        char page[MAX_REQUEST_SIZE] = {0};
        
        for (x = 0; buffer[x] != '\n' && x < MAX_REQUEST_SIZE - 1; x++)
            request[x] = buffer[x];
    
        request[x] = '\0';

        int res = get_reqest_page(request, page);
        printf("%s this", page);
        if(!res)
        {
            printf("- Page %s not found!\n", page);
            count = 0;
            count += sprintf(buffer + count, "HTTP/1.0 404 File not found\n");
            count += sprintf(buffer + count, "Server: VSWSInC/0.0\n");
            count += sprintf(buffer + count, "Connection: close\n");
            count += sprintf(buffer + count, "Content-type: text/plain\n");
            count += sprintf(buffer + count, "Content-Length: 9\n");
            count += sprintf(buffer + count, "\nRequested page Not Found\n");
            send(connfd, buffer, count, 0);

            close(connfd);
        }
        if (strcmp(page, "mypage.html") == 0)
        {
            FILE *page = fopen("mypage.html", "r");
            fseek(page, 0, SEEK_END);
            int fsize = ftell(page);
            fseek(page, 0, SEEK_SET);
            char *content = (char *)calloc(fsize, sizeof(char));
            fread(content, sizeof(char), fsize, page);

            printf("\n%s\n", content);
            bzero(buffer, 0);
            fclose(page);

            count = 0;
            count += sprintf(buffer + count, "HTTP/1.0 200 OK\n");
            count += sprintf(buffer + count, "Server: VSWSInC/0.0\n");
            count += sprintf(buffer + count, "Content-type: text/html\n");
            count += sprintf(buffer + count, "Content-Length: %d\n", fsize);

            count += sprintf(buffer + count, "\n%s\n", content);

            send(connfd, buffer, count, 0);
            }
        
        else if (strlen(page) == 0)
        {
             bzero(buffer, 0);
            printf("Home page!\n");
            count = 0;
            count += sprintf(buffer + count, "HTTP/1.0 404 File not found\n");
            count += sprintf(buffer + count, "Server: VSWSInC/0.0\n");
            count += sprintf(buffer + count, "Connection: close\n");
            count += sprintf(buffer + count, "Content-type: text/plain\n");
            count += sprintf(buffer + count, "Content-Length: 9\n");
            count += sprintf(buffer + count, "\nWelcome to the Dept. of CSE!\n");
            send(connfd, buffer, count, 0);
        }
        else
        {
            printf("- Page %s not found!\n", page);
            count = 0;
             bzero(buffer, 0);
            count += sprintf(buffer + count, "HTTP/1.0 404 File not found\n");
            count += sprintf(buffer + count, "Server: VSWSInC/0.0\n");
            count += sprintf(buffer + count, "Connection: close\n");
            count += sprintf(buffer + count, "Content-type: text/plain\n");
            count += sprintf(buffer + count, "Content-Length: 9\n");
            count += sprintf(buffer + count, "\n404 error: Requested page Not Found\n");
            send(connfd, buffer, count, 0);
            close(connfd);
        }
  
    }	
	close(sockfd);
	
	
	return 0; 
} 