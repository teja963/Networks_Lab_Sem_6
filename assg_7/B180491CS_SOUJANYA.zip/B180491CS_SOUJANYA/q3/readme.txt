gcc s.c -o s
./s

go to localhost:8080