// Server side implementation of UDP client-server model 
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 

#define PORT_NUMBER	 8080
#define SA struct sockaddr
#define MAXLINE 1024 
char *hello = "HTTP/1.1 200 OK\nContent-Type: text/plain\nContent-Length: 30\n\nWelcome to Networks Lab!\n";
// Driver code 
int main() { 
	int sockfd, connfd, len; 
	struct sockaddr_in servaddr, cli; 
	int n; 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) { 
		printf("socket creation failed...\n"); 
		exit(0); 
	} 
	else
		printf("Socket successfully created..\n"); 

	memset(&servaddr,0, sizeof(servaddr));
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT_NUMBER);

	// Binding newly created socket to given IP and verification 
	if ((bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr))) != 0) { 
		printf("Socket bind failed\n"); 
		exit(0); 
	} 
	else
		printf("Socket successfully binded\n"); 

	// Now server is ready to listen and verification 
	if ((listen(sockfd, 5)) != 0) { 
		printf("Listen failed\n"); 
		exit(0); 
	} 
	else
		printf("Server listening\n"); 
	len = sizeof(cli); 

	// Accept the data packet from client and verification 
	
    while(1)
    {
        connfd = accept(sockfd, (SA*)&cli, &len); 
        if (connfd < 0) { 
            printf("Server acccept failed\n"); 
            exit(0); 
        } 
        else
            printf("Server acccept the client\n"); 
        printf("\n[+] New Client Request has been received.\n");
        char buffer[30000] = {0};
        long valread = read( connfd , buffer, 30000);
        printf("%s\n",buffer );
        write(connfd , hello , strlen(hello));
        printf("The Message has been sent to the client.\n");
        close(connfd);
    }

	
	
	close(sockfd);
	
	
	return 0; 
} 