function click() {
    console.log("JAVASCRIPT");
}