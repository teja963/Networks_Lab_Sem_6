#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    FILE *fpipe;
    char *template = "nslookup -type=%s -port=1234 %s 127.0.0.1";
    char c = 0;
    printf("WELCOME TO DNS CLIENT\n");
    printf("press ctr-D to end\n");
    char command[255];

    char name[255];
    char type[100];

    while (1) {
        printf("DOMAIN NAME: ");
        if (scanf("%s%*c", name) == EOF)
            break;

        printf("TYPE: ");
        if (scanf("%s%*c", type) == EOF)
            break;

        if (!(  strcmp(type, "a") == 0 ||
                strcmp(type, "aaaa") == 0 ||
                strcmp(type, "cname") == 0 ||
                strcmp(type, "ns") == 0)) {
            printf("UNAUTHORISED\n");
            continue;
        }

        sprintf(command, template, type, name);

        if (0 == (fpipe = (FILE*)popen(command, "r")))
        {
            perror("popen() failed.");
            exit(EXIT_FAILURE);
        }

        while (fread(&c, sizeof c, 1, fpipe))
        {
            printf("%c", c);
        }

        pclose(fpipe);
    }

    printf("\nBye\n");

    return EXIT_SUCCESS;
}