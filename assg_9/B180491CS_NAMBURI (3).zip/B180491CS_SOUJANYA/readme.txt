gcc LocalDNSServer.c -lpthread -o LocalDNSServer
./LocalDNSServer
PORT: 1234

gcc DNSClient.c && ./a.out
follow the instructions
