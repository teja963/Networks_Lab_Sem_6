gcc client.c -o cl
gcc server.c -o se
gcc popserver.c -o pop
